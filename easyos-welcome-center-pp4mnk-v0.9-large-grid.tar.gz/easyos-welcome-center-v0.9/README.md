# EasyOS Welcome Center v0.9 Large Grid

Created by pp4mnk.

A large no-scroll Welcome Center / Control Center for EasyOS, using standard EasyOS/Puppy/GTK icons with fallbacks.

## Install

```bash
tar -xzf easyos-welcome-center-pp4mnk-v0.9-large-grid.tar.gz
cd easyos-welcome-center-v0.9
chmod +x install.sh
./install.sh
```

## Run

```bash
easyos-welcome-center
```

## Design

- Large 1080x740 window
- 6 columns x 6 rows
- No scrolling
- 36 buttons visible at once
- Standard icon lookup from EasyOS/Puppy paths
- Safe helper scripts included
