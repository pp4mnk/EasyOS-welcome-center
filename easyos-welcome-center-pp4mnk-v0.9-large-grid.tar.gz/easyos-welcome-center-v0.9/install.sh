#!/bin/sh
set -e
SRC_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
DEST="/usr/local/easyos-welcome-center"
mkdir -p "$DEST" /usr/local/bin /usr/share/applications
cp -a "$SRC_DIR/bin" "$SRC_DIR/scripts" "$DEST/"
chmod +x "$DEST/bin/easyos-welcome-center" "$DEST/scripts/"*.sh
ln -sf "$DEST/bin/easyos-welcome-center" /usr/local/bin/easyos-welcome-center
cat > /usr/share/applications/easyos-welcome-center.desktop <<'DESK'
[Desktop Entry]
Type=Application
Name=EasyOS Welcome Center
Comment=EasyOS Control Center by pp4mnk
Exec=easyos-welcome-center
Icon=computer
Terminal=false
Categories=Settings;System;
DESK
printf '\nInstalled. Run with:\n  easyos-welcome-center\n\n'
