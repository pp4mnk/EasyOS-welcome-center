# EasyOS Welcome Center 1.1 — pp4mnk

## Instalación recomendada
Abra easyos-welcome-center-1.1-noarch.pet con PKGget y confirme su instalación.
Requiere yad (instalable desde PKGget). No incluye binarios de otras distribuciones.
Abra Menu > System > EasyOS Welcome Center, o ejecute:

    easyos-welcome-center

Si el menú no se actualiza, ejecute fixmenus y recargue JWM desde el menú.

## Instalación alternativa desde este directorio
En EasyOS, como root:

    sh install.sh
    easyos-welcome-center --check
    easyos-welcome-center

Para probar sin instalar: sh bin/easyos-welcome-center
No mezcle la instalación manual con PET. El PET registra los archivos en PKGget.
Si una versión anterior se instaló manualmente, retírela antes de instalar el PET.

## Prueba en tu EasyOS
1. Ejecute easyos-welcome-center --check. Debe terminar en PASS.
2. Abra la ventana desde System y pruebe System info, Doctor, Terminal y File manager.
3. Pruebe Firefox/Slimjet: se da prioridad a los lanzadores /files/portable/*-ram.sh,
   si existen; si no, se buscan los comandos instalados. No se añade --no-sandbox.
4. Pruebe Applications (easyapps), Packages (PKGget) y Snapshot (Easy Version Control).
   Una utilidad ausente debe mostrar un aviso; las rutas varían según versión.
5. Cierre y abra la ventana. En pantallas pequeñas debe poder desplazarse.
6. Si falla algo, guarde el informe:

       easyos-welcome-center --check > /root/ewc-check.txt 2>&1
       easyos-welcome-center > /root/ewc-launch.txt 2>&1

El diagnóstico comprueba dependencias y sintaxis, no verifica automáticamente
que cada aplicación externa abra bien. Los lanzadores respetan las herramientas
existentes del sistema. Los diálogos Backup, Save session, Containers, Updates,
Word-like tips y Font advice son informativos: no realizan esas operaciones.
Performance info es de solo lectura. Internet test comprueba conectividad, no velocidad.
El benchmark usa CPU y salida /dev/null; no mide rendimiento de disco.

## Desinstalar
PET: gestor PKGget. Manual: sh /usr/local/easyos-welcome-center/uninstall.sh

## Cambios
- Acciones YAD se mantienen abiertas y se ejecutan mediante un despachador validado.
- Menú System, icono propio y versión coherente 1.1.
- Se eliminan cambios al pinboard ROX y el reinicio forzoso del escritorio.
- Snapshot ya no llama a snapmergepuppy; Save session no fuerza guardados.
- Packages y Applications abren herramientas gráficas; no apt sin argumentos.
- Temporales únicos y borrado al cerrar; sin limpieza por comodines.
- Benchmark sin archivos de escritura ni nombres temporales compartidos.
- Diagnóstico --check y mensajes de funciones ausentes.

## Validación de esta entrega
Comprobados sintaxis POSIX con sh, formato .desktop, referencias a acciones,
creación/instalación/desinstalación en un directorio aislado, integridad del PET
y despacho con sustitutos de aplicaciones. No se dispone aquí de EasyOS ni de
YAD/X11: la prueba visual real y la apertura de utilidades nativas quedan pendientes
en el equipo de destino. No se afirma que la GUI esté validada en EasyOS.

Formato PET: https://easyos.org/dev/coding-for-easyos.html
Herramientas nativas: https://www.easyos.org/user/easy-version-upgrade-and-downgrade.html
