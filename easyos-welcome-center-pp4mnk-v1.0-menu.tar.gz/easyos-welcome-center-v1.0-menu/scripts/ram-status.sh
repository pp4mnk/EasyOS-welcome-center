#!/bin/sh
. "$(dirname "$0")/_lib.sh"
term "RAM status" 'free -h; echo; swapon --show 2>/dev/null; echo; zramctl 2>/dev/null || true; echo; cat /proc/meminfo | sed -n "1,12p"'
