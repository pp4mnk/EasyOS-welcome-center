#!/bin/sh
. "$(dirname "$0")/_lib.sh"
run_first easy-version-control snapmergepuppy
