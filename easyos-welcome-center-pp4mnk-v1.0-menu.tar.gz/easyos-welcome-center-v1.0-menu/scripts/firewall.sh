#!/bin/sh
. "$(dirname "$0")/_lib.sh"
run_first firewall_ng firewallinstallshell firewallstatus gufw
