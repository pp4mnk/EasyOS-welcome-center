#!/bin/sh
. "$(dirname "$0")/_lib.sh"
mkdir -p /root/.config/libreoffice/4/user/config
cat > /tmp/easyos-wordlike.txt <<TXT
This helper prepares a Word-like LibreOffice setup idea:

Recommended font substitutions:
Calibri -> Carlito
Cambria -> Caladea
Arial -> Liberation Sans
Times New Roman -> Liberation Serif
Courier New -> Liberation Mono

Open LibreOffice:
Tools -> Options -> LibreOffice -> Fonts
Enable: Apply replacement table
TXT
msg "LibreOffice Word-like" "$(cat /tmp/easyos-wordlike.txt)"
