#!/bin/sh
. "$(dirname "$0")/_lib.sh"
TMP=/tmp/easyos-welcome-system.txt
{
echo "EasyOS Welcome Center - System info"
echo "------------------------------------"
echo "Hostname: $(hostname)"
echo "Kernel: $(uname -r)"
echo "Architecture: $(uname -m)"
echo "CPU: $(grep -m1 'model name' /proc/cpuinfo 2>/dev/null | cut -d: -f2-)"
echo
echo "Memory:"; free -h
echo
echo "Disks:"; df -h | sed -n '1,12p'
echo
echo "Working dir candidates:"; ls -d /mnt/wkg /mnt/* 2>/dev/null | head
} > $TMP
yad --text-info --title="System info" --width=760 --height=560 --filename=$TMP --button=OK:0
