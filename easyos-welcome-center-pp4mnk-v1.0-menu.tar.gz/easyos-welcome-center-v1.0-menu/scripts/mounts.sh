#!/bin/sh
. "$(dirname "$0")/_lib.sh"
term "Mounted drives" 'lsblk -f 2>/dev/null || true; echo; mount | sed -n "1,25p"; echo; df -h'
