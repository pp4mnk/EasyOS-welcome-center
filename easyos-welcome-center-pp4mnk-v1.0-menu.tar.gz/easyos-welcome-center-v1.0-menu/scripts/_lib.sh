#!/bin/sh
msg(){ yad --center --width=700 --height=420 --title="$1" --text="$2" --button=OK:0 2>/dev/null || xmessage "$1

$2"; }
term(){ if command -v urxvt >/dev/null; then urxvt -title "$1" -e sh -c "$2; echo; echo Press ENTER to close; read x"; elif command -v rxvt >/dev/null; then rxvt -title "$1" -e sh -c "$2; echo; echo Press ENTER to close; read x"; elif command -v xterm >/dev/null; then xterm -T "$1" -e sh -c "$2; echo; echo Press ENTER to close; read x"; else sh -c "$2"; fi; }
open_url(){ URL="$1"; for b in defaultbrowser firefox chromium chromium-browser slimjet seamonkey; do command -v $b >/dev/null 2>&1 && { $b "$URL" >/dev/null 2>&1 & exit 0; }; done; msg "Browser not found" "No browser command was found."; }
run_first(){ for c in "$@"; do command -v "$c" >/dev/null 2>&1 && { "$c" >/dev/null 2>&1 & exit 0; }; done; msg "Not found" "None of these commands exists:\n$*"; }
