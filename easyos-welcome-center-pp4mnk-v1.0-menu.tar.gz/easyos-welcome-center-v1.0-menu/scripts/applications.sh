#!/bin/sh
. "$(dirname "$0")/_lib.sh"
run_first jwm_menu_create fixmenus pexec
