#!/bin/sh
. "$(dirname "$0")/_lib.sh"
run_first petget ppm pkgget synaptic apt
