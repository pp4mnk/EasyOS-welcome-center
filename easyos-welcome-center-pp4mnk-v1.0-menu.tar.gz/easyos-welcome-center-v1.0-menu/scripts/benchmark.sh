#!/bin/sh
. "$(dirname "$0")/_lib.sh"
term "Quick benchmark" 'echo "CPU gzip test"; dd if=/dev/zero bs=1M count=128 2>/dev/null | gzip -c >/tmp/easyos-bench.gz; ls -lh /tmp/easyos-bench.gz; rm -f /tmp/easyos-bench.gz; echo; echo "Filesystem write test"; dd if=/dev/zero of=/tmp/easyos-write-test bs=1M count=128 conv=fdatasync; rm -f /tmp/easyos-write-test; echo; free -h'
