#!/bin/sh
. "$(dirname "$0")/_lib.sh"
msg "Backup" "Suggested EasyOS backup:\n\n1. Create a snapshot first.\n2. Copy your working folder to an external USB drive.\n3. Keep a second copy before experimenting.\n\nThis button is intentionally safe and does not copy/delete files automatically."
