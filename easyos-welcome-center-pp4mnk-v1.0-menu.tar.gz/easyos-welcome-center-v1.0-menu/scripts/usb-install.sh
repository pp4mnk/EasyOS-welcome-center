#!/bin/sh
. "$(dirname "$0")/_lib.sh"
run_first easydd bootflash install-to-usb usb-installer gparted
