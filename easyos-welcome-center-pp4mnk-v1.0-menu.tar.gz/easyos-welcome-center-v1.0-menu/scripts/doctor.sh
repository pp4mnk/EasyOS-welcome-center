#!/bin/sh
. "$(dirname "$0")/_lib.sh"
term "EasyOS Doctor" 'echo "EasyOS Doctor by pp4mnk"; echo; command -v yad && echo "OK: yad" || echo "MISSING: yad"; command -v defaultbrowser && echo "OK: defaultbrowser" || echo "INFO: defaultbrowser not found"; command -v libreoffice && echo "OK: LibreOffice" || echo "INFO: LibreOffice not found"; free -h; echo; df -h; echo; ip route 2>/dev/null; echo; cat /etc/resolv.conf 2>/dev/null'
