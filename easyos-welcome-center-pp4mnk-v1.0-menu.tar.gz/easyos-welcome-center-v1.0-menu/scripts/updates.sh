#!/bin/sh
. "$(dirname "$0")/_lib.sh"
msg "Updates" "For EasyOS updates, use the official EasyOS update mechanism and snapshots.\n\nRecommended order:\n1. Create snapshot\n2. Update\n3. Reboot\n4. Keep or rollback"
