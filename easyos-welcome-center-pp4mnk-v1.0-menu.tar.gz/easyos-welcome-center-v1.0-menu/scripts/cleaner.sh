#!/bin/sh
. "$(dirname "$0")/_lib.sh"
rm -rf /tmp/easyos-welcome-* /tmp/easyos-bench.gz /tmp/easyos-write-test 2>/dev/null
msg "Cleaner" "Temporary files from this Welcome Center were cleaned.\n\nNo personal files were touched."
