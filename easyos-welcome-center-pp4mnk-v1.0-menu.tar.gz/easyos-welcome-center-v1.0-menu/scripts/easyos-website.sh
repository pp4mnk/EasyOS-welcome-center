#!/bin/sh
. "$(dirname "$0")/_lib.sh"
open_url "https://easyos.org/"
