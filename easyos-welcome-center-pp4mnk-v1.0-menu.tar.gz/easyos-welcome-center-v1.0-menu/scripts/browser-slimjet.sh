#!/bin/sh
. "$(dirname "$0")/_lib.sh"
run_first slimjet flashpeak-slimjet defaultbrowser
