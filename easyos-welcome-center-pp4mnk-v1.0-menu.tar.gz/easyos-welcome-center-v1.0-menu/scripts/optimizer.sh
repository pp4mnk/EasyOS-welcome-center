#!/bin/sh
. "$(dirname "$0")/_lib.sh"
term "Safe optimizer" 'echo "Safe checks only - no risky changes"; echo; sysctl vm.swappiness 2>/dev/null; echo; cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || true; echo; free -h; echo; echo "You can add your pp4mnk optimizer commands here."'
