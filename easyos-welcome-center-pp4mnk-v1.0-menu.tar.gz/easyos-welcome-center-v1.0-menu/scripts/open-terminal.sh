#!/bin/sh
for t in urxvt rxvt xterm sakura lxterminal xfce4-terminal; do command -v $t >/dev/null 2>&1 && { $t & exit 0; }; done
xmessage "No terminal found"
