#!/bin/sh
. "$(dirname "$0")/_lib.sh"
msg "Help" "EasyOS Welcome Center by pp4mnk\n\nUse the buttons to open common EasyOS tools.\nMost buttons first try EasyOS/Puppy standard commands and show information if a tool is not installed."
