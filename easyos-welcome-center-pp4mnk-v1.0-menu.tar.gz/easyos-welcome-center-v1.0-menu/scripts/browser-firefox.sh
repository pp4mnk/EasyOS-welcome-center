#!/bin/sh
. "$(dirname "$0")/_lib.sh"
run_first firefox firefox-esr defaultbrowser
