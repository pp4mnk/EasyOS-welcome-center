#!/bin/sh
. "$(dirname "$0")/_lib.sh"
open_url "https://forum.puppylinux.com/viewforum.php?f=63"
