#!/bin/sh
. "$(dirname "$0")/_lib.sh"
run_first chromium chromium-browser google-chrome defaultbrowser
