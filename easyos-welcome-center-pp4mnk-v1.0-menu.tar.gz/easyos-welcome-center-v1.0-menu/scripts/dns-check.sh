#!/bin/sh
. "$(dirname "$0")/_lib.sh"
term "DNS check" 'cat /etc/resolv.conf; echo; command -v nslookup >/dev/null && nslookup easyos.org || true'
