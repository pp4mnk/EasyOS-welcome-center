#!/bin/sh
. "$(dirname "$0")/_lib.sh"
run_first quicksetup first-run wizardwizard controlpanel pcc
