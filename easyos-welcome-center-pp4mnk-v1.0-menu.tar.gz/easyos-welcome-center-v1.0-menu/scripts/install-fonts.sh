#!/bin/sh
. "$(dirname "$0")/_lib.sh"
mkdir -p /usr/share/fonts/truetype/pp4mnk-compatible 2>/dev/null
fc-cache -fv >/tmp/easyos-font-cache.log 2>&1
msg "Fonts" "Font folder checked:\n/usr/share/fonts/truetype/pp4mnk-compatible\n\nTip: install Carlito, Caladea and Liberation fonts if they are not already present.\n\nFont cache refreshed."
