#!/bin/sh
mkdir -p /root/Startup /root/.config/autostart
rox /root/Startup 2>/dev/null || xdg-open /root/Startup 2>/dev/null || xmessage "/root/Startup"
