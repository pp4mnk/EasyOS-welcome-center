#!/bin/sh
. "$(dirname "$0")/_lib.sh"
run_first defaults-chooser defaultapps pdefaultchooser
