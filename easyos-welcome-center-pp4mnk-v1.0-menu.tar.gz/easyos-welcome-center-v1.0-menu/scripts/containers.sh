#!/bin/sh
. "$(dirname "$0")/_lib.sh"
msg "Containers" "EasyOS includes its own container philosophy.\n\nUse the native EasyOS container tools from the desktop/menu when available.\n\nThis button is a safe placeholder so the Welcome Center does not break if container tools differ between versions."
