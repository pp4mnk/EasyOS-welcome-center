#!/bin/sh
. "$(dirname "$0")/_lib.sh"
msg "About" "EasyOS Welcome Center / Control Center\nVersion 0.9 Large Grid\n\nCreated by pp4mnk\n\nGoal: make EasyOS easier for normal users without breaking its lightweight philosophy."
