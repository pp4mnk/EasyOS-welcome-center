#!/bin/sh
for f in rox pcmanfm thunar spacefm; do command -v $f >/dev/null 2>&1 && { $f /root & exit 0; }; done
xmessage "No file manager found"
