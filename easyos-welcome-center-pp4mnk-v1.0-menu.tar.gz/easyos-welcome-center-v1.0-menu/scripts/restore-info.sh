#!/bin/sh
. "$(dirname "$0")/_lib.sh"
msg "Restore / Snapshots" "Use Easy Version Control / snapshots to restore previous states.\n\nThis helper does not restore automatically to avoid accidental data loss."
