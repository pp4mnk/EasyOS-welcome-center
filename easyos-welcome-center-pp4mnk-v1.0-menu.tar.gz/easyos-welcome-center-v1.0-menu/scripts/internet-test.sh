#!/bin/sh
. "$(dirname "$0")/_lib.sh"
term "Internet test" 'echo "Route:"; ip route 2>/dev/null; echo; echo "DNS:"; cat /etc/resolv.conf; echo; ping -c 4 1.1.1.1 2>/dev/null; echo; ping -c 4 easyos.org 2>/dev/null'
