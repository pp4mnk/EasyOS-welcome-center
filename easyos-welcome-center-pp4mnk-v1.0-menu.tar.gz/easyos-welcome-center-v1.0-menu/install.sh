#!/bin/sh
# EasyOS Welcome Center installer by pp4mnk
# Installs executable + menu entry in EasyOS/Puppy/JWM.
set -e

SRC_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
DEST="/usr/local/easyos-welcome-center"
BIN_LINK="/usr/local/bin/easyos-welcome-center"
DESKTOP_FILE="/usr/share/applications/easyos-welcome-center.desktop"
PIXMAP_DIR="/usr/local/share/pixmaps"
ICON_FILE="$PIXMAP_DIR/easyos-welcome-center.png"

need_root() {
  if [ "$(id -u)" != "0" ]; then
    echo "Please run this installer as root."
    exit 1
  fi
}

find_icon() {
  for name in easyos.png easy.png computer.png system.png applications-system.png chromium.png web-browser.png; do
    for dir in /usr/share/pixmaps /usr/local/lib/X11/pixmaps /usr/local/share/pixmaps /usr/share/icons/hicolor/48x48/apps /usr/share/icons/hicolor/64x64/apps /usr/share/icons/hicolor/128x128/apps /usr/share/icons/Adwaita/48x48/apps /usr/share/icons/Adwaita/32x32/apps; do
      [ -f "$dir/$name" ] && { echo "$dir/$name"; return; }
    done
  done
  echo ""
}

make_fallback_icon() {
  mkdir -p "$PIXMAP_DIR"
  # Small built-in PNG generated from base64, used only if no system icon is found.
  base64 -d > "$ICON_FILE" <<'B64'
iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAIAAADYYG7QAAAACXBIWXMAAA7EAAAOxAGVKw4bAAABHklEQVR4nO2YQQ6DMAwE2f//0y9QJYpCQKDUVVVPRaQqgXGIJA57nTgS/Pz8/AKgAWgAGoAGoAGYcx13R6PR9/39rWma3W63rutSSo3j+O9kWaYMg8MwR0fH+fn5+Xy+JElCCHmeZ4zhcDiMMTqdTqfT7/c7HA6apnFZltfr9TAMp9OJJEnSNI3j+Gaz2e12t9td1/Wmafr9fr/fb7fbYRjGtm3btq3r+qIojuO4XC6/3+/3+9PT0zAM4/F4PB7P5/N8Pp8sy6Zp2rZt27Zt27Zt27Zt27Zt27Zt27Zt2/ZfGgC4A7w/9mN8+eO3+z2fz+f7/T6fz+f7/X6/3+/3+32/3+93u93v97vd7vd7vR7H8e12u91uN5vN9/v9brfb7XabzWZVVVXX9f0GACwAGoAGoAF4AF/JPsxQ0RX5AAAAAElFTkSuQmCC
B64
}

need_root

mkdir -p "$DEST" /usr/local/bin /usr/share/applications "$PIXMAP_DIR"
cp -a "$SRC_DIR/bin" "$SRC_DIR/scripts" "$DEST/"
chmod +x "$DEST/bin/easyos-welcome-center" "$DEST/scripts/"*.sh
ln -sf "$DEST/bin/easyos-welcome-center" "$BIN_LINK"

SYS_ICON="$(find_icon)"
if [ -n "$SYS_ICON" ]; then
  cp -f "$SYS_ICON" "$ICON_FILE" || make_fallback_icon
else
  make_fallback_icon
fi
chmod 644 "$ICON_FILE"

cat > "$DESKTOP_FILE" <<EOF2
[Desktop Entry]
Version=1.0
Type=Application
Name=EasyOS Welcome Center
GenericName=EasyOS Control Center
Comment=EasyOS Welcome Center by pp4mnk
Exec=easyos-welcome-center
Icon=$ICON_FILE
Terminal=false
Categories=System;Settings;Utility;
StartupNotify=true
EOF2
chmod 644 "$DESKTOP_FILE"

# Refresh desktop database when available.
if command -v update-desktop-database >/dev/null 2>&1; then
  update-desktop-database /usr/share/applications >/dev/null 2>&1 || true
fi

# Puppy/EasyOS/JWM menu regeneration.
if command -v fixmenus >/dev/null 2>&1; then
  fixmenus >/dev/null 2>&1 || true
fi

# Restart/reload JWM so Menu -> System appears immediately.
if command -v jwm >/dev/null 2>&1; then
  jwm -restart >/dev/null 2>&1 || jwm -reload >/dev/null 2>&1 || true
fi

# Refresh ROX pinboard/icons if available.
if command -v rox >/dev/null 2>&1; then
  rox -p /root/Choices/ROX-Filer/PuppyPin >/dev/null 2>&1 || true
fi

cat <<MSG

EasyOS Welcome Center has been installed.

Launch from terminal:
  easyos-welcome-center

Or from the menu:
  Menu -> System -> EasyOS Welcome Center

If the menu entry does not appear immediately, restart JWM or reboot.

MSG
