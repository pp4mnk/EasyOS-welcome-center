#!/bin/sh
set -e
rm -rf /usr/local/easyos-welcome-center
rm -f /usr/local/bin/easyos-welcome-center
rm -f /usr/share/applications/easyos-welcome-center.desktop
rm -f /usr/local/share/pixmaps/easyos-welcome-center.png
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database /usr/share/applications >/dev/null 2>&1 || true
command -v fixmenus >/dev/null 2>&1 && fixmenus >/dev/null 2>&1 || true
command -v jwm >/dev/null 2>&1 && { jwm -restart >/dev/null 2>&1 || jwm -reload >/dev/null 2>&1 || true; }
echo "EasyOS Welcome Center removed."
