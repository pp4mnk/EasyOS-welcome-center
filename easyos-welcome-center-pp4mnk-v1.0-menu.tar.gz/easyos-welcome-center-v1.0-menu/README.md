# EasyOS Welcome Center v1.0 Menu Fix

Large grid control center by pp4mnk.

This version fixes menu integration in EasyOS/Puppy/JWM:

- Installs the executable to `/usr/local/bin/easyos-welcome-center`
- Creates `/usr/share/applications/easyos-welcome-center.desktop`
- Installs an icon to `/usr/local/share/pixmaps/easyos-welcome-center.png`
- Runs `fixmenus`
- Restarts/reloads JWM so the entry appears in the menu

## Install

```bash
tar -xzf easyos-welcome-center-pp4mnk-v1.0-menu.tar.gz
cd easyos-welcome-center-v1.0-menu
chmod +x install.sh
./install.sh
```

## Run

```bash
easyos-welcome-center
```

Or use:

**Menu -> System -> EasyOS Welcome Center**

## Uninstall

```bash
./uninstall.sh
```
